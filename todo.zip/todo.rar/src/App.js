import logo from "./logo.svg";
import "./App.css";
import { useEffect, useState } from "react";

const tasks = [
  { name: "sadfsf", status: true },
  { name: "bbbb", status: false },

  { name: "cccccc", status: false },

  { name: "read book", status: true },
];

function App() {
  // (localStorage.setItem('jobs', tasks));
  const storageJobs = JSON.parse(localStorage.getItem("jobs"));
  // console.log("storage", storageJobs);
  const [job, setJob] = useState({ name: "", status: true }); // {name:'', status: ''}
  const [jobs, setJobs] = useState(tasks);
  const [editJob, setEditJob] = useState(-1);
  const [updateJob, setUpdateJob] = useState(true);
  const [keywork, setKeywork] = useState();

  const [avatar, setAvatar] = useState();

  useEffect(() => {
    localStorage.setItem("jobs", JSON.stringify(tasks));
    // setJobs(JSON.parse(localStorage.getItem('jobs')))
  }, []);

  const handleInput = (e) => {
    // setJob(e.target.value)
    var name = e.target.name;

    var value = e.target.value;
    let fJob = { ...job };
    // console.log(typeof value);
    if (name === "status") {
      fJob[name] = value === "1";
    } else {
      fJob[name] = value;
    }
    setJob(fJob);
    
  };

  const clickADD = (o) => {
    o.preventDefault();
    const newJobs = [...jobs, job];
    // console.log("new", newJobs);
    if (job.name !== "") {
      setJobs(newJobs);
      const jsonJobs = JSON.stringify(newJobs);
      localStorage.setItem("jobs", jsonJobs);
      setJob({ name: "", status: true });
    }
    // console.log('job',job)
    // setJob({name: '', status:true})

    // if (!job) {
    //   alert('fill input');
    // } else if (job && !updateItem) {
    //   let tmp = -1;
    //   jobs.find((item, index) => {
    //   if(updateJobs === item){
    //     tmp = index
    //   }
    //   let dll = [...jobs];
    //   console.log(updateJobs)
    //   dll.splice( tmp , 1, job);
    //   setJobs(dll);
    //  }); 
    //   setUpdateItem(true)
    // } else {
    //   setJobs(x => [...x,job])
    //   document.querySelector('#input').value = ''
    //   setJob('')     
    // }  
  };

  

  const handleDeleteAll = () => {
    setJobs((x) => []);
    setJob("");
  };

  const handleDelete = (c) => {
    let de = -1;
    jobs.forEach((item, index) => {
      if (c === item) {
        de = index;
      }
    });
    let del = [...jobs];
    del.splice(de, 1);
    setJobs(del);
  };

  const handleClickEdit = (j, index) => {
    
    //  console.log("abcd", j, index);
      setJob(j);
    //  console.log( 'job',job)
    setEditJob(index);
    setUpdateJob(false)
  };

  const clickEdit = () => {
    let ejb = -1;
    jobs.find((item, index) => {
      if ( editJob === index) {
        ejb = index;
      }
    });
    
    

    let dell = [...jobs];
    dell.splice(ejb, 1, job);
    setJobs(dell);
    setEditJob(dell);
    setUpdateJob(true)
  };

  const handlePreviewAvatar = (n) => {
    const file = n.target.files[0];

    file.preview = URL.createObjectURL(file);
    setAvatar(file);
  };

  const handleinputSearch =(e) => {
    var value = e.target.value;
    
    
    if (value === ""){
      console.log('check null')
      setJobs(JSON.parse(localStorage.getItem("jobs")))
    }else{
      let setKeywork = jobs.filter(job => {
        return job.name.toUpperCase().includes(value.toUpperCase())
      })
      setJobs(setKeywork)
    }

    

  }

  const ClickSearch = (e) => {
    
    

  }

  // console.log("jobs", jobs);
  return (
    <div>
      <div className="text-center">
        <h1>Quản Lý Công Việc</h1>
        <hr />
      </div>
      <div className="row">
        <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4">
          <div className="panel panel-warning">
            <div className="panel-heading">
              <h3 className="panel-title">Thêm Công Việc</h3>
            </div>
            <div className="panel-body" id="">
              <form>
                <div className="form-group">
                  <label>Tên :</label>
                  <input
                    onChange={(e) => handleInput(e)}
                    name="name"
                    value={job.name}
                    className="form-control"
                    placeholder="fill input"
                  ></input>
                </div>
                <label>Trạng Thái :</label>
                <select
                  onChange={(e) => handleInput(e)}
                  name="status"
                  className="form-control"
                  required="required"
                >
                  <option value={1}>Kích Hoạt</option>
                  <option value={0}>Ẩn</option>
                </select>
                <br />
              </form>
              <div className="text-center">
                {updateJob ?<button
                  onClick={clickADD}
                  type="submit"
                  className="btn btn-warning"
                >
                 Thêm 
                </button>: <div></div>}
                &nbsp;
                <button
                  onClick={handleDeleteAll}
                  type="submit"
                  className="btn btn-danger"
                >
                  Xóa hết
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xs-8 col-sm-8 col-md-8 col-lg-8">
          <div className="row mt-15">
            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <div className="input-group">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Nhập từ khóa..."
                  onChange={e=> handleinputSearch(e)}
                  value={keywork}
                  name='keywork'
                />
                <span className="input-group-btn">
                  <button className="btn btn-primary" type="button" >
                    <span className="fa fa-search mr-5"></span>Tìm
                  </button>
                </span>
              </div>
            </div>
            <div className="col-xs-6 col-sm-6 col-md-6 col-lg-6">
              <div className="dropdown">
                <button
                  className="btn btn-primary dropdown-toggle"
                  type="button"
                  id="dropdownMenu1"
                  data-toggle="dropdown"
                  aria-haspopup="true"
                  aria-expanded="true"
                  onClick={ClickSearch}
                >
                  Sắp Xếp{" "}
                  <span className="fa fa-caret-square-o-down ml-5"></span>
                </button>
                <ul className="dropdown-menu" aria-labelledby="dropdownMenu1">
                  <li>
                    <a role="button">
                      <span className="fa fa-sort-alpha-asc pr-5">Tên A-Z</span>
                    </a>
                  </li>
                  <li>
                    <a role="button">
                      <span className="fa fa-sort-alpha-desc pr-5">
                        Tên Z-A
                      </span>
                    </a>
                  </li>
                  <li role="separator" className="divider"></li>
                  <li>
                    <a role="button">Trạng Thái Kích Hoạt</a>
                  </li> 
                  <li>
                    <a role="button">Trạng Thái Ẩn</a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="row mt-15">
            <div className="col-xs-12 col-sm-12 col-md-12 col-lg-12">
              <table className="table table-bordered table-hover">
                <thead>
                  <tr>
                    <th className="text-center">STT</th>
                    <th className="text-center">Tên</th>
                    <th className="text-center">Trạng Thái</th>
                    <th className="text-center">Hành Động</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td>
                      <input type="text" className="form-control" />
                    </td>
                    <td>
                      <select className="form-control">
                        <option value="-1">Tất Cả</option>
                        <option value="0">Ẩn</option>
                        <option value="1">Kích Hoạt</option>
                      </select>
                    </td>
                    <td></td>
                  </tr>
                  {jobs.map((item, index) => (
                    <tr key={index}>
                      <td>{index + 1}</td>
                      <td>
                        <span onClick={e=> handleClickEdit(item, index)} key={index}>{item.name}</span>
                      </td>
                      <td className="text-center">
                        <span className={`label label-success ${item.status ?'KH' : 'An'}`} >{item.status ? 'Kich hoat' : 'An'}</span>
                      </td>
                      <td className="text-center">
                        <button
                          onClick={(e) => clickEdit()}
                          type="button"
                          className="btn btn-warning"
                        >
                          <span onClick={e =>clickEdit()} className="fa fa-pencil mr-5"></span>Sửa
                        </button>
                        &nbsp;
                        <button
                          onClick={(e) => handleDelete(item)}
                          type="button"
                          className="btn btn-danger"
                        >
                          <span className="fa fa-trash mr-5"></span>Xóa
                        </button>
                      </td>
                    </tr>
                  ))}
                  {/* {
                                          jobs?.map((job, index)=>(
                                            
                                          
                                             <tr key={index}>
                                                <td>1</td>
                                                <td><span onClick={e=> handleClickEdit(job, index)} key={index} >{job}</span></td>
                           
                                                <td className="text-center">
                                                  <span className="label label-success">
                                                     Kích Hoạt
                                                  </span>
                                                </td>
                                                <td className="text-center">
                                                  <button onClick={e =>clickEdit()} type="button" className="btn btn-warning">
                                                      <span  className="fa fa-pencil mr-5"></span>Sửa
                                                  </button>
                                                  &nbsp;
                                                  <button onClick={e => handleDelete(job)} type="button" className="btn btn-danger">
                                                      <span className="fa fa-trash mr-5"></span>Xóa
                                                  </button>
                                                </td>
                                             </tr>

                                           ))
                                    } */}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      <input type="file" onChange={handlePreviewAvatar} />
      {avatar && <img src={avatar.preview} alt="" width="80%" />}
    </div>
  );
}

export default App;
